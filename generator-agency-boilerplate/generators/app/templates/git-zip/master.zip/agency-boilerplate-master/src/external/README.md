external source folder e.g. tracking script

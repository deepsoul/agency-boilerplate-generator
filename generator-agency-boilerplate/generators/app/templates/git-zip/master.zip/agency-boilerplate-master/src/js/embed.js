"use strict";

require('./embed/fontfaceObserver');

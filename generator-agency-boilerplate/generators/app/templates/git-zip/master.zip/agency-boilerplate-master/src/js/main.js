"use strict";

var js = require('./services/parser/js');

(function(){
    $(function() {
        js.parse();
    }); 
})();

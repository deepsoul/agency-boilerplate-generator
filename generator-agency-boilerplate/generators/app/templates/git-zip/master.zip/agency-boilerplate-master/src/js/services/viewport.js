"use strict";

module.exports = new (require('../base/Viewport'))();
